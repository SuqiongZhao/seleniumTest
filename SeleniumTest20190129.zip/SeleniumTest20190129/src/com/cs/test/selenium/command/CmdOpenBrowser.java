package com.cs.test.selenium.command;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

import com.cs.test.selenium.util.ENV;

import AT.fileUtils;

public class CmdOpenBrowser{
	
//	public CmdOpenBrowser() {
//		super();
//	}

	public static void run(String fieldSelector,String fieldValue){
		WebDriver driver=null;
		if(fieldValue==null){
			fieldValue=fileUtils.getBrowser();
		}
		
		if ("chrome".equalsIgnoreCase(fieldValue)){
			
			System.setProperty("webdriver.chrome.driver", ".\\lib\\chromedriver.exe");
			driver = new ChromeDriver();
			
		}else if("ie".equalsIgnoreCase(fieldValue)){
			
			System.setProperty("webdriver.ie.driver", ".\\lib\\IEDriverServer.exe"); 
			driver = new InternetExplorerDriver();
			
		}else if ("firefox".equalsIgnoreCase(fieldValue)){
			
			System.setProperty("webdriver.gecko.driver", ".\\lib\\geckodriver.exe");
			driver = new FirefoxDriver();
		}
		System.out.println("open "+fieldValue+" success!");
		
		try {
			ENV.setCurrentDriver(driver);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
	}
	
	public void run(){
		String openBrowser=fileUtils.getBrowser();
		run(null,openBrowser);
	}
	
	public static void run(String fieldValue){
		run(null,fieldValue);
	}

}
