package com.cs.test.selenium.command;

import org.openqa.selenium.WebDriver;

import AT.fileUtils;

import com.cs.test.selenium.util.ENV;

public class CmdCloseBrowser {
	
	public static void run(String fieldSelector,String fieldValue){
		WebDriver driver = ENV.getDriver();
		driver.quit();
		System.out.println("close Browser successfully!");
	}
	
	
	public static void run(){
		run(null,null);
	}

}
