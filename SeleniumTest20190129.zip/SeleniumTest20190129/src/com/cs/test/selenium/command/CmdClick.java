package com.cs.test.selenium.command;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.cs.test.selenium.util.elementUtils;

import com.cs.test.selenium.util.ENV;

public class CmdClick {
	
	private static void run(String selector,String fieldValue){
		WebElement element;
		WebDriver driver = ENV.getDriver();
		element=elementUtils.bySelector(driver, selector);
		try {
			element.click();
			System.out.println("click  "+selector+" success");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public static void run(String selector){
		run(selector,null);
	}

}
