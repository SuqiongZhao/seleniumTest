package com.cs.test.selenium.command;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.cs.test.selenium.util.ENV;

import AT.elementUtils;
import AT.operateCommond;

public class CmdWait {
	
//	public CmdWait(String target) {
//		super();
//	}
	
	private static void run(String selector,String fieldValue){
		WebElement element;
		WebDriver driver = ENV.getDriver();
		
		if(fieldValue==null && selector!=null){
			WebElement waitEle;
			waitEle=elementUtils.bySelector(driver, selector);
			WebDriverWait wait=new WebDriverWait(driver,15);
			wait.until(ExpectedConditions.visibilityOf(waitEle));

		}else if(fieldValue!=null && selector!=null){
			WebElement waitEle;
			waitEle=elementUtils.bySelector(driver, selector);
			operateCommond.waitForValue(fieldValue,waitEle,driver);
		}else if (fieldValue!=null && selector==null){
			try {
				TimeUnit.SECONDS.sleep(Integer.parseInt(fieldValue));
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("wait:"+fieldValue+"s");
		}

	}
	
	public static void run(String selector){
		run(selector,null);
	}
	
	public static void run(int fieldValue){
		run(null,String.valueOf(fieldValue));
	}

//	private void waitTime(String target){
//		long waitTime = 0L;
//		int index = getNonDigitalIndex(target);
//		if(index<0){
//			waitTime = Integer.valueOf(target).intValue() * 1000L;
//		}else{
//			int number = Integer.valueOf(target.substring(0, index));
//			String unit = target.substring(index).toLowerCase();
//			if("s".equals(unit)){
//				waitTime = number * 1000L;
//			}else if("ms".equals(unit)){
//				waitTime = number;
//			}else if("m".equals(unit)){
//				waitTime = number * 60L * 1000L;
//			}else{
//				waitTime = number * 1000L;
//			}
//		}
//		try {
//			Thread.sleep(waitTime);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
//	
//	private int getNonDigitalIndex(String s){
//		char[] cs = s.toCharArray();
//		for(int i=0;i<cs.length;i++){
//			char c = cs[i];
//			if(c<'0' || c>'9'){
//				return i;
//			}
//		}
//		return -1;
//	}
	

}
