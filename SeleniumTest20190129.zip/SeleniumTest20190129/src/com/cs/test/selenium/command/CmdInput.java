package com.cs.test.selenium.command;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.cs.test.selenium.util.ENV;
import com.cs.test.selenium.util.elementUtils;

public class CmdInput {
	
	public static void run(String selector,String fieldValue){
		WebElement element;
		WebDriver driver = ENV.getDriver();
		element=elementUtils.bySelector(driver, selector);

		element.clear();
		element.sendKeys(fieldValue);
		System.out.println("input: "+selector+" success");
		
	}

}
