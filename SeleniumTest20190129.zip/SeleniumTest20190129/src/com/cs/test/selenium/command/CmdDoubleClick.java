package com.cs.test.selenium.command;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.cs.test.selenium.util.ENV;
import com.cs.test.selenium.util.elementUtils;

public class CmdDoubleClick {
	private static void run(String selector,String fieldValue){
		WebElement element;
		WebDriver driver = ENV.getDriver();
		element=elementUtils.bySelector(driver, selector);
		Actions action = new Actions(driver);
		action.doubleClick(element).perform();
		System.out.println("double click" +selector+" success");
	}
	
	
	public static void run(String selector){
		run(selector,null);
	}
}
