package com.cs.test.selenium.testsuit;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.cs.test.selenium.Log.logType;
import com.cs.test.selenium.Log.logUtils;
import com.cs.test.selenium.util.ExcelUtils;
import com.cs.test.selenium.util.pathUtils;
import com.cs.test.selenium.util.reportUtils;

public class AutoTestStep {
	
	public static String testScenior=null;
	
	//read CASE sheet in Configure file
	public static void getConfigFile(String configPath){
		XSSFWorkbook configWB=ExcelUtils.getExcelFile(configPath);
		XSSFSheet caseSH=ExcelUtils.getSheet(configWB, "CASE");
		int caseCountRow=ExcelUtils.getSheetCountRow(caseSH);
		for(int i=1;i<=caseCountRow;i++){
			String flag=ExcelUtils.getCellData(caseSH,i, 1);
			if(flag.equals("Y")){
				String caseName=ExcelUtils.getCellData(caseSH,i, 0);
				String casePath=pathUtils.getCasePath(caseName+".xlsx");
				logUtils.Output(logType.LogTypeName.INFO, "-----------"+caseName+" Start Run-----------");
				getCaseFile(casePath);
				logUtils.Output(logType.LogTypeName.INFO,"-----------"+caseName+" End Run-----------");
				
			}
			
		}
		
		
	}
	
	//read List sheet in CASE file
	public static void getCaseFile(String casePath) {
		XSSFWorkbook caseWB=ExcelUtils.getExcelFile(casePath);
		XSSFSheet listSH=ExcelUtils.getSheet(caseWB, "List");
		int caseCountRow=ExcelUtils.getSheetCountRow(listSH);
		for(int i=1;i<=caseCountRow;i++){
			testScenior=ExcelUtils.getCellData(listSH,i, 0);
			if(!testScenior.contains("//")){
				logUtils.Output(logType.LogTypeName.INFO,"-----"+testScenior+" Start Run-----");
				getScenior(caseWB,testScenior);
				reportUtils.writeResult(testScenior, "PASS");
				logUtils.Output(logType.LogTypeName.INFO,"-----"+testScenior+" End Run-----");
				
			}
		}
	
	}

	//Execute specific test steps
	public static void getScenior(XSSFWorkbook wbName,String sceniorName){
		// TODO Auto-generated method stub
		XSSFSheet sceniorSH=ExcelUtils.getSheet(wbName, sceniorName);
		int caseCountRow=ExcelUtils.getSheetCountRow(sceniorSH);
		for(int i=1;i<=caseCountRow;i++){
			String iKeyWord=ExcelUtils.getCellData(sceniorSH,i, 0);
			if(!iKeyWord.contains("//")){
				//String iCaseStep=ExcelUtils.getCellData(sceniorSH,i, 0);
				//String iKeyWord=ExcelUtils.getCellData(sceniorSH,i, 1);
				String iSelector=ExcelUtils.getCellData(sceniorSH,i, 1);
				String iValue=ExcelUtils.getCellData(sceniorSH,i, 2);
				try {
					testsuit.execute_Actions(iKeyWord, iSelector, iValue);
					logUtils.Output(logType.LogTypeName.INFO,iKeyWord+" PASS");
				} catch (Exception e) {
					// TODO Auto-generated catch block
					logUtils.Output(logType.LogTypeName.ERROR,iKeyWord+" [Fail]");
					//ActionsKeywords.savescreen("", "FailPage_"+(new SimpleDateFormat("yyyyMMddhhmmss")).format(new Date())+".jpg");
					reportUtils.writeResult(sceniorName, "FAIL");
					e.printStackTrace();
				}

			}
			
		}

	}
	

}
