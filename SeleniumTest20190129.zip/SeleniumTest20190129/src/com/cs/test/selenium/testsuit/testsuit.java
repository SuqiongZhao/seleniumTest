package com.cs.test.selenium.testsuit;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import com.cs.test.selenium.Log.logType;
import com.cs.test.selenium.Log.logUtils;
import com.cs.test.selenium.command.CommandFactory;
import com.cs.test.selenium.common.operateCommond;
import com.cs.test.selenium.util.pathUtils;

public class testsuit {
	
	public static void main(String[] args){
		operateCommond.initializaAT();
		logUtils.Output(logType.LogTypeName.INFO,"Initializa complete!");
		String config_path = pathUtils.getConfigPath("conifg.xlsx");
		AutoTestStep.getConfigFile(config_path);
	}
	
	
	public static void execute_Actions(String iKeyWord,String iSelector,String iValue) throws NoSuchMethodException, SecurityException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		// TODO Auto-generated method stub
		CommandFactory cf=new CommandFactory();
		Class<?> actionKeywords = cf.parseTestCommand(iKeyWord);
		Method methodName;
		Class[] types = {String.class,String.class};
		

			methodName=actionKeywords.getDeclaredMethod("run",types);
			methodName.setAccessible(true);
			Object obj = actionKeywords.newInstance();
	        methodName.invoke(obj, iSelector,iValue);

		
	}
}
