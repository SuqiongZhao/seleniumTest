package com.cs.test.selenium.Tool;

import java.net.MalformedURLException;
import java.net.URL;

import br.eti.kinoshita.testlinkjavaapi.TestLinkAPI;

public class TestlinkContainer {
	
	public static void main(String[] args) throws MalformedURLException{
		
		String url = "http://http://10.119.169.66/testlink/lib/api/xmlrpc/v1/xmlrpc.php";
	    String devKey = "615f68f991035e6d178b2ff108b2ae62";
	     
	    URL testlinkURL = new URL(url);
	    TestLinkAPI api = new TestLinkAPI(testlinkURL,devKey);

	    System.out.println(api.ping());
	}

}
