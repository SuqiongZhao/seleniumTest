package com.cs.test.selenium.Tool;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Arrays;
import java.util.List;
import java.util.Map;




public class DBContainer {
	
	
	public static Connection DBConnect(Map<String,String>  map){

		 //Declare connection objects
		Connection connection;
		String driver = "com.mysql.jdbc.Driver";  //set mysql driver
		String url="jdbc:mysql://"+map.get("host")+":"+String.valueOf(map.get("port"))+"/"+map.get("db"); //set mysql connection url
		String user = map.get("user");
		String password=map.get("password");
		try {
			Class.forName(driver);
			connection = DriverManager.getConnection(url,user,password);
			if(!connection.isClosed()){
				System.out.println("Succeeded connecting to the Database!");
				
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Failed connecting to the Database!");
			connection=null;
			e.printStackTrace();
		}
		return connection;
		

	}
	
	public static int executeSQL(Map<String,String>  map,String sqlString){
		Connection conn=DBConnect(map);
		ResultSet rs=null;
		Statement statement=null;
		
		int count = 0;
		
		try {
			statement= conn.createStatement();
			
			
			if(sqlString.trim().toLowerCase().startsWith("select")){
				
				rs = statement.executeQuery(sqlString);

				while(rs.next()){

					if(sqlString.contains("count(*)")){
						count = Integer.valueOf(rs.getString(1));
					}else{
						count+=1;
					}
				}
				
				System.out.println("search data in MySQL,the total result is : "+count);
				
			}else if(sqlString.trim().toLowerCase().startsWith("update")){
				statement.executeUpdate(sqlString);
				System.out.println("update data in MySQL successfully");
			}else if(sqlString.trim().toLowerCase().startsWith("delete")){
				statement.executeUpdate(sqlString);
				System.out.println("update data in MySQL successfully");
			}

		}catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if (rs != null)
					rs.close();
			} catch (Exception ee) {

			}
		}

		return count;
	}
	
	
	public static void excuteUpdateSQL(Map<String,String> map,String sqlString,String para){
		
		Connection conn=DBConnect(map);
		List<String> parameters =Arrays.asList(para.split(","));
		
		PreparedStatement ps = null;

		try {
			ps = conn.prepareStatement(sqlString);
			for (int i = 0; i < parameters.size(); i++) {
				ps.setString(i + 1, parameters.get(i));
			}
			ps.executeUpdate();	
			
		} catch (SQLException e) {

			e.printStackTrace();
		}finally {
			try {
				if (ps != null)
					ps.close();
			} catch (Exception ee) {

			}
		}
	}
	

}
