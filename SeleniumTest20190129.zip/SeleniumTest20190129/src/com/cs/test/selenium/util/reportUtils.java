package com.cs.test.selenium.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.cs.test.selenium.common.operateCommond;

public class reportUtils {
	
	public static String currentDate=operateCommond.getCurrentDate();
	public static String reportName="TestReport"+"_"+currentDate.replace("-", "")+".xlsx";
	//public static String  reportTempPath = pathUtils.getReportPath()+currentDate+"\\";
	public static String  reportTempPath = pathUtils.getReportPath()+"\\";
	public static FileOutputStream os=null;
	
	public static void createReportFile(){
		File srcFile = new File(pathUtils.getConfigPath("TestReport_Template.xlsx"));
		File destFile = new File(reportTempPath+reportName);
		if(destFile.exists()){
			destFile.delete();
		}
		try {
			FileUtils.copyFile(srcFile, destFile);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		updateTitle();
	}
	
	public static void updateTitle(){
		
		XSSFSheet caseSH=ExcelUtils.getSheet(ExcelUtils.getExcelFile(pathUtils.getConfigPath("conifg.xlsx")), "ENV_INFO");
		String reportTitle="Env Info:\r\n"+ExcelUtils.getCellData(caseSH,3, 1)+"\r\n";
		reportTitle=reportTitle+ExcelUtils.getCellData(caseSH,8, 1)+"+"+ExcelUtils.getCellData(caseSH,10, 1)+"+"+ExcelUtils.getCellData(caseSH,12, 1)+"\r\n";
		reportTitle=reportTitle+ExcelUtils.getCellData(caseSH,13, 1);
		
		XSSFWorkbook reportWB=ExcelUtils.getExcelFile(reportTempPath+reportName);
		XSSFSheet reportSH=ExcelUtils.getSheet(reportWB, "TestCase");
		reportSH.getRow(1).getCell(0).setCellValue(reportTitle);
		try {
			os = new FileOutputStream(reportTempPath+reportName);
			reportWB.write(os);
			os.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public static void writeResult(String caseID,String resultStr){
		String reportCase="";
		String result="";
		Cell cell1=null;
		Cell cell2=null;
		
		Workbook reportWB = ExcelUtils.getExcelFile(reportTempPath+reportName);
		Sheet reportSH=reportWB.getSheet("TestCase");
		CellStyle style=reportWB.createCellStyle();
		style.setFillForegroundColor(IndexedColors.RED.getIndex());
		style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		style.setAlignment(HorizontalAlignment.CENTER);
		
		int countRow=reportSH.getLastRowNum();
		for(int i=0;i<=countRow;i++){
			reportCase=reportSH.getRow(i).getCell(0).getStringCellValue();
			result=reportSH.getRow(i).getCell(4).getStringCellValue();
			if(reportCase.equals(caseID)&& StringUtils.isEmpty(result)){
				cell1=reportSH.getRow(i).getCell(4);
				cell2=reportSH.getRow(i).getCell(5);
				cell1.setCellValue(resultStr);
				cell2.setCellValue(currentDate);
				if((resultStr.toLowerCase()).equals("fail")){
					cell1.setCellStyle(style);
				}
				
				try {
					os = new FileOutputStream(reportTempPath+reportName);
					reportWB.write(os);
					os.close();
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				break;
			}
		}
		
		
	}

}
