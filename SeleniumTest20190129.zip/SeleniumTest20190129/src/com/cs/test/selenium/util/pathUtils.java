package com.cs.test.selenium.util;

import java.io.File;



public class pathUtils {
	private static  String rootPath = "./";
	
	
	public static String getRootPath(){
		return rootPath;
	}
	
	public static String getConfigPath(String fileName){
		return rootPath+"/dataEngine/"+fileName;
		
	}
	
	public static String getCasePath(String fileName){
		return rootPath+"/dataEngine/Test Case/"+fileName;
		
	}
	
	public static String getLogPath(){
		return rootPath+"/Result/log/";
		
	}
	
	public static String getReportPath(){
		return rootPath+"/Result/report/";
		
	}
	
	public static String getResultPicPath(){
		return rootPath+"/Result/Result_PIC/";
		
	}
	
	

}
