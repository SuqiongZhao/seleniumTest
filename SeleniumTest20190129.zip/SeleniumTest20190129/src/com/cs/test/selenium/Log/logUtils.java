package com.cs.test.selenium.Log;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.cs.test.selenium.common.operateCommond;
import com.cs.test.selenium.util.pathUtils;


public class logUtils {
	
	public static String currentDate=operateCommond.getCurrentDate();
	public static String logName=currentDate.replace("-", "")+"_"+"CaseLog.log";
	//public static String  logPath = pathUtils.getLogPath()+currentDate+"\\";
	
	public static String  logPath = pathUtils.getLogPath()+"\\";
	
	public logUtils(){
		
	}
	
	public static void createLogs(){
		File file=new File(logPath+logName);
		if(file.exists()){
			file.delete();
		}
		try {
			file.createNewFile();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void writeLogs(String strLogs){
		File file=new File(logPath+logName);
		FileWriter fw;
		try {
			fw = new FileWriter(file, true);
			BufferedWriter bw = new BufferedWriter(fw);
			//bw.write((new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")).format(new Date())+" "+strLogs);
			bw.write(strLogs);
			bw.flush();
			bw.close();
			fw.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public static void Output(logType.LogTypeName logTypeName, String logMessage){  
		String strLogs= (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")).format(new Date()); 
        strLogs = strLogs + " " + logTypeName.name() + ": " + logMessage + "\r\n";  
        writeLogs(strLogs);  
        // 定义一个开关，为True就输出日志，如果你不想输出，改成False
//        if (LogFlag)  
//            WriteLog(logEntry);  
//        }
	}
	
	public static void readLogs(String strLogs){
		try {
			FileReader fr = new FileReader(logPath+logName);
			BufferedReader br = new BufferedReader(fr);
			String str = br.readLine();
			System.out.println(strLogs);
		} catch (Exception e) {
			System.out.println("The log file can not found!");
			e.printStackTrace();
			
		}
	}
	
	

}
