package com.cs.test.selenium.Log;

public class logType {
	
	public logType(){  
        
    }  
      
    public enum LogTypeName{  
          
        //  
        INFO,  
        //  
        ERROR,  
        //  
        WARNING,  
        //  
        DEBUG;  
    }  

}
