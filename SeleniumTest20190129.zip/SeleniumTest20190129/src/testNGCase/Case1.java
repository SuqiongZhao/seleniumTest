package testNGCase;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;


public class Case1 {
  
  @BeforeTest
  public void beforeTest() {
	  System.out.println("beforeTest");
  }
  

  @Test
  public void f1(){
	  System.out.println("f1");
	  //ActionsKeywords_KTEC.openBrowser("Chrome");
	  //ActionsKeywords_KTEC.openURL("https://www.baidu.com/");

  }
  
  @Test(dependsOnMethods = { "f1" })
  public void f2() throws InterruptedException, IOException{
	  System.out.println("f2");
	  //ActionsKeywords_KTEC.input("id=kw", "java");
  }

  @AfterTest
  public void afterTest() {
	  System.out.println("afterTest");
  }

}
