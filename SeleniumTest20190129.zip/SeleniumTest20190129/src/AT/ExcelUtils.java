package AT;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtils {
	public static XSSFWorkbook workbook;
	public static XSSFSheet worksheet;
	public static XSSFCell cell;
	
	//get workbook object
	public static XSSFWorkbook getExcelFile(String path){
		
		InputStream demoFile;
		try {
			demoFile = new FileInputStream(path);
			workbook = new XSSFWorkbook(demoFile);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
		return workbook;
	}
	//get worksheet object
	public static XSSFSheet getSheet(XSSFWorkbook wbName,String sheetName){
		return worksheet=wbName.getSheet(sheetName);

	}
	
	//get worksheet total row
	public static int getSheetCountRow(XSSFSheet wbSH){
		
		return wbSH.getLastRowNum();
	}
	
	//get cell dataֵ
	public static  String getCellData(XSSFSheet wbSH,int rowNumber,int colNumber){
		cell = wbSH.getRow(rowNumber).getCell(colNumber);
		String cellData;
		if (cell!=null){

			cellData=cell.getStringCellValue();

		}
		else{
			 cellData="";
		}
		
		return cellData;
	}	

}
